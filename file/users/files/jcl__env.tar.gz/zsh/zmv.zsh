# http://zshwiki.org/home/builtin/functions/zmv
autoload -U zmv
