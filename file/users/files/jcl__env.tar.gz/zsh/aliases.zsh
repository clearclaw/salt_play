alias -g ...='../..'
alias -g ....='../../..'
alias -g .....='../../../..'
alias -g ......='../../../../..'
alias 1='cd -'
alias 2='cd -2'
alias 3='cd -3'
alias 4='cd -4'
alias 5='cd -5'
alias 6='cd -6'
alias 7='cd -7'
alias 8='cd -8'
alias 9='cd -9'

alias  psme="ps -ef | fgrep ${LOGNAME}"
alias  psf="ps -ef | fgrep -v grep | grep -i"
alias  he="fc -l | egrep"
alias  h='fc -l'
alias  funcl="typeset -f"
alias  funcd="unset -f"
alias  j=jobs
alias  m='nice make -k > make.out 2>&1 &'
alias  e='emacsclient -n'
alias  ee='emacs -nw'

alias d="ls -lasp --color=none"
alias dd="ls -dCasp --color=none"
alias l="less"
alias qw="ls -CFapx --color=none"
alias rd="rmdir"
alias t="cat"
alias xl="xless"
alias tf="tail -f"

alias c='tput clear'
alias f="fgrep"
alias md="mkdir -p"
alias reset="tput reset"
alias wh="whereis"
alias who="who -Hu"
alias whoami="who am i"

alias rr="nd r"
alias rrr="nd rr"
alias tt="nd t"
alias ttt="nd tt"

alias ut="tar ztvf"
alias ux="tar zxvf"

alias ve="workon"
alias lve="lsvirtualenv"
alias cd_ve="cdvirtualenv"
alias cd_ves="cdsitepackages"
alias cd_vels="lssitepackages"
alias new_ve="mkvirtualenv"
alias rm_ve="rmvirtualenv"

if [ "$GDMSESSION" != "" ]
then
  alias open="xdg-open"
fi