function zsh_stats() {
  fc -l 1 | awk '{CMD[$2]++;count++;}END { for (a in CMD)print CMD[a] " " CMD[a]/count*100 "% " a;}' | grep -v "./" | column -c3 -s " " -t | sort -nr | nl |  head -n20
}

function take() {
  mkdir -p $1
  cd $1
}

#
# Get the value of an alias.
#
# Arguments:
#    1. alias - The alias to get its value from
# STDOUT:
#    The value of alias $1 (if it has one).
# Return value:
#    0 if the alias was found,
#    1 if it does not exist
#
function alias_value() {
    alias "$1" | sed "s/^$1='\(.*\)'$/\1/"
    test $(alias "$1")
}

#
# Try to get the value of an alias,
# otherwise return the input.
#
# Arguments:
#    1. alias - The alias to get its value from
# STDOUT:
#    The value of alias $1, or $1 if there is no alias $1.
# Return value:
#    Always 0
#
function try_alias_value() {
    alias_value "$1" || echo "$1"
}

#
# Set variable "$1" to default value "$2" if "$1" is not yet defined.
#
# Arguments:
#    1. name - The variable to set
#    2. val  - The default value 
# Return value:
#    0 if the variable exists, 3 if it was set
#
function default() {
    test `typeset +m "$1"` && return 0
    typeset -g "$1"="$2"   && return 3
}

#
# Set enviroment variable "$1" to default value "$2" if "$1" is not yet defined.
#
# Arguments:
#    1. name - The env variable to set
#    2. val  - The default value 
# Return value:
#    0 if the env variable exists, 3 if it was set
#
function env_default() {
    env | grep -q "^$1=" && return 0 
    export "$1=$2"       && return 3
}

# Create and change into a directory
function nd {
  mkdir -p $1
  cd $1
}

# Try to recover from a confused terminal state.
function fixterm {
  typeset CURSTTY

  CURSTTY=`stty -g`
  if [ $CURSTTY = $STTY ]
  then
    echo no change required
  else
    stty $STTY
    echo login settings restored
  fi
}

# Git-based version string, aligns with pyver
function gitver {
  git describe --long --tags --match '[0-9]*.[0-9]*' --dirty
}

function resize {
  eval `/usr/bin/X11/resize -h "$@"`
}

function lpman {
  if [ $# -gt 0 ]
  then
    for fl in $*
    do
      unifdef -t -UB1 $fl | tbl -TX | neqn | nroff -man | col -x
    done
  else
    unifdef -t -UB1 | tbl -TX | neqn | nroff -man | col -x
  fi
}

# With this helper function, you can do a lot more actually: Say you are
# in ~/src/zsh/Src/Builtins and want to go to ~/src/zsh. Just say up
# zsh. Or even just up z.
# And as a bonus, if you capture the output of up, it will print the
# directory you want, and not change to it. So you can do:
# mv foo.c $(up zsh)

up() {
  local op=print
  [[ -t 1 ]] && op=cd
  case "$1" in
    '') up 1;;
    -*|+*) $op ~$1;;
    <->) $op $(printf '../%.0s' {1..$1});;
    *) local -a seg; seg=(${(s:/:)PWD%/*})
       local n=${(j:/:)seg[1,(I)$1*]}
       if [[ -n $n ]]; then
         $op /$n
       else
         print -u2 up: could not find prefix $1 in $PWD
         return 1
       fi
  esac
}

# If you are an avid Emacs user like me, you’ll find this function
# useful. It enters the directory the currently active Emacs file
# resides in:
cde() {
  cd ${(Q)~$(emacsclient -e '(with-current-buffer
                               (window-buffer (selected-window))
                               default-directory) ')}
}

# For a cheap, but secure password generator, you can use this:
zpass() {
  LC_ALL=C tr -dc '0-9A-Za-z_@#%*,.:?!~' < /dev/urandom | head -c${1:-10}
  echo
}
