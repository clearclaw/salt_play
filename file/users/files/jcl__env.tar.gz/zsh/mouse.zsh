# Ctrl highlights the mouse cursor
if [ "${DESKTOP_SESSION}" = "ubuntu" ]
then
  gsettings set org.gnome.settings-daemon.peripherals.mouse locate-pointer true
fi
